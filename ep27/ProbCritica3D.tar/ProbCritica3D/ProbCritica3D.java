/***************************************************************
* Nome: Lucas Stefan Abe
* Nº USP: 8531612
*
* Compilação: javac-algs4 ProbCritica3D.java
* Execução: java-algs4 ProbCritica3D N M
*
* O que o programa faz? 
* Programa que recebe um inteiro N da matrix NxNxN e um inteiro
* M de testes e imprime um valor estimado para a probabilidade
* crítica na saída padrão.
*
****************************************************************/
public class ProbCritica3D {
	// Variáveis globais
	public static double xc = 0.0;
	public static double distancia = 1.0;
	public static double fc = 0.0;
	
	// retorna uma matrix booleana aleatoria NxNxN, onde
    // cada entrada é verdadeira com probabilidade p
    public static boolean[][][] random (int N, double p) {
        boolean[][][] a = new boolean[N][N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
            	for (int k = 0; k < N; k++)
                	a[i][j][k] = StdRandom.bernoulli (p);
        return a;
    }

    // faz M experimentos e retorna a fração que percola
    public static double eval (int N, double p, int M) {
        int count = 0;
        for (int k = 0; k < M; k++) {
            boolean[][][] open = ProbCritica3D.random (N, p);
            if (Percolation3D.percolates (open))
                count++;
        }
        return (double) count / M;
    }

    // plotagem recursiva da curva
    public static void curve (int N, double x0, double y0, double x1, double y1, int M) {
        double gap = .01;
        double err = .0025;
        double xm = (x0 + x1) / 2;
        double ym = (y0 + y1) / 2;
	
		if (Math.abs (0.5 - y0) < ProbCritica3D.distancia) {
			ProbCritica3D.xc = x0;
			ProbCritica3D.fc = y0;
			ProbCritica3D.distancia = Math.abs (0.5 - y0);
		}
		if (Math.abs (0.5 - y1) < ProbCritica3D.distancia) {
			ProbCritica3D.xc = x1;
			ProbCritica3D.fc = y1;
			ProbCritica3D.distancia = Math.abs (0.5 - y1);
		}
        double fxm = ProbCritica3D.eval (N, xm, M);
        if (x1 - x0 < gap || Math.abs (ym - fxm) < err) 
            return;
        curve (N, x0, y0, xm, fxm, M);
        //StdDraw.filledCircle (xm, fxm, .005);
        curve (N, xm, fxm, x1, y1, M);
    }

    public static void main (String[] args) {
    	int N = Integer.parseInt (args[0]);
		int M = Integer.parseInt (args[1]);
	
    	ProbCritica3D.curve (N, 0.0, 0.0, 1.0, 1.0, M);
		StdOut.println ("Probabilidade critica = " + ProbCritica3D.xc);
    }
}